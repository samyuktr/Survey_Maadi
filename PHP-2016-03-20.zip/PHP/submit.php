<?php
require 'connect.php';

extract($_POST);

$result=mysql_query("SELECT f_no FROM main");
$f_no = mysql_num_rows($result);


$area = "BSK"; #Hard coded Area for now

if($hospital == "Excellent")
	$hospital = 1;
elseif($hospital == "Great")
	$hospital = 2;
elseif($hospital == "Fair")
	$hospital = 3;
elseif($hospital == "Poor")
	$hospital = 4;
else
	$hospital = 0;

if(! isset($query))
{
	$query = '';
}

if(! isset($feedback))
{
	$feedback = '';
}

if($info == "Yes")
	$info = 1;
else
	$info = 0;
	
	
$insert_main = "INSERT INTO `main`(`f_no`, `area`, `name`, `total_child`, `child_b4`, `hospital`, `info`, `query`, `feedback`) VALUES ('{$f_no}','{$area}','{$name}','{$total_child}','{$child_b4}','{$hospital}','{$info}','{$query}','{$feedback}')";
$result = mysql_query($insert_main);


if(!$result)
	echo mysql_error();
else
{
	if($total_child > 0){
		#Loop through total no of children
		#insert all the age and vac details
		
		$count = $total_child - $child_b4;
		
		for($i = 1; $i <=$total_child; $i++)
		{
			//For every child, regardless of age I need to insert something into the child-vac table. Okay.
			//Now the variable names won't be straight forward, need to work around
			
			$result=mysql_query("SELECT c_no FROM child_vac");
			$c_no = mysql_num_rows($result);
			
			if(${'polio'.$i} == "Yes")
					$polio = 1;
			else
				$polio = 0;
				
			if(${'bcg'.$i} == "Yes")
					$bcg = 1;
			else
				$bcg = 0;
			
			if(${'tetanus'.$i} == "Yes")
					$tetanus = 1;
			else
				$tetanus = 0;
			
			if(${'rotavirus'.$i} == "Yes")
					$rotavirus = 1;
			else
				$rotavirus = 0;
			
			if(${'hepatitis'.$i} == "Yes")
					$hepatitis = 1;
			else
				$hepatitis = 0;
			
			if(${'measles'.$i} == "Yes")
					$measles = 1;
			else
				$measles = 0;
			
			if(${'influenza'.$i} == "Yes")
					$influenza = 1;
			else
				$influenza = 0;
				
			$insert_child_vac = "INSERT INTO `child_vac`(`c_no`, `f_no`, `age`, `polio`, `bcg`, `tetanus`, `hepatitis`, `rotavirus`, `measles`, `influenza`) VALUES ('{$c_no}','{$f_no}','{${'age'.$i}}','{$polio}','{$bcg}','{$tetanus}','{$hepatitis}','{$rotavirus}','{$measles}','{$influenza}')";
			
			$result = mysql_query($insert_child_vac);
			
			if($count > 0)
			{
				if(${'schooling'.$i} == "Yes")
					$scing = 1;
				else
					$scing = 0;
					
				if(${'school'.$i} == "Government")
					$sc = 1;
				else
					$sc = 0;
				

				$insert_child_sc = "INSERT INTO `child_sch`(`c_no`, `schooling`, `school`) VALUES ('{$c_no}','{$scing}','{$sc}')";
				$result = mysql_query($insert_child_sc);
				
				$count--;
			}
		}
	}	
	echo"Done!";
}

?>