-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2014 at 02:10 PM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mse_1`
--

-- --------------------------------------------------------

--
-- Table structure for table `child_sch`
--

CREATE TABLE IF NOT EXISTS `child_sch` (
  `c_no` int(11) NOT NULL,
  `schooling` tinyint(1) NOT NULL,
  `school` tinyint(4) NOT NULL,
  PRIMARY KEY (`c_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `child_vac`
--

CREATE TABLE IF NOT EXISTS `child_vac` (
  `c_no` int(11) NOT NULL,
  `f_no` int(11) NOT NULL,
  `age` int(11) NOT NULL,
  `polio` tinyint(1) NOT NULL,
  `bcg` tinyint(1) NOT NULL,
  `tetanus` tinyint(1) NOT NULL,
  `hepatitis` tinyint(1) NOT NULL,
  `rotavirus` tinyint(1) NOT NULL,
  `measles` tinyint(1) NOT NULL,
  `influenza` tinyint(1) NOT NULL,
  PRIMARY KEY (`c_no`,`f_no`),
  KEY `f_key1` (`f_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `main`
--

CREATE TABLE IF NOT EXISTS `main` (
  `f_no` int(11) NOT NULL,
  `Area` varchar(30) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `total_child` int(11) NOT NULL,
  `child_b4` int(11) NOT NULL,
  `hospital` tinyint(4) NOT NULL,
  `info` tinyint(1) NOT NULL,
  `query` varchar(100) DEFAULT NULL,
  `feedback` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `child_sch`
--
ALTER TABLE `child_sch`
  ADD CONSTRAINT `fkey_2` FOREIGN KEY (`c_no`) REFERENCES `child_vac` (`c_no`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `child_vac`
--
ALTER TABLE `child_vac`
  ADD CONSTRAINT `f_key1` FOREIGN KEY (`f_no`) REFERENCES `main` (`f_no`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
